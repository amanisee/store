const CACHE_NAME = 'robopragma-v8.2.2-cache-v1'; // Ubah nama cache setiap kali Anda mengubah aset
const urlsToCache = [
    './', // Cache root (index.html)
    'index.html',
    'manifest.json',
    'https://robopragma.boutique/images/logo.webp', // Cache logo
    // Tambahkan semua URL ikon di sini
    'icons/icon-72x72.png',
    'icons/icon-96x96.png',
    'icons/icon-128x128.png',
    'icons/icon-144x144.png',
    'icons/icon-152x152.png',
    'icons/icon-192x192.png',
    'icons/icon-384x384.png',
    'icons/icon-512x512.png',
    'https://www.icegif.com/wp-content/uploads/2023/02/icegif-1692.gif' // Cache gif untuk redirect
];

self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Opened cache');
                return cache.addAll(urlsToCache);
            })
            .catch(error => {
                console.error('Failed to cache during install:', error);
            })
    );
});

self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request)
            .then(response => {
                // Cache hit - return response
                if (response) {
                    return response;
                }
                // No cache hit - fetch from network
                return fetch(event.request).catch(() => {
                    // Jika fetch gagal (offline), bisa menyediakan fallback
                    // Contoh: return caches.match('/offline.html');
                });
            })
    );
});

self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheName !== CACHE_NAME) {
                        console.log('Deleting old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});